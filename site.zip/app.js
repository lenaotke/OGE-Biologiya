'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const view = $('task-view'), select = $('category-filter');
  const menu = document.querySelector('.nav-toggle');
  function closeMenu(){document.body.classList.remove('nav-open');menu.setAttribute('aria-expanded','false');}
  menu.addEventListener('click',()=>{const open=document.body.classList.toggle('nav-open');menu.setAttribute('aria-expanded',String(open));if(open)document.querySelector('.nav-close button').focus();});
  document.querySelector('.nav-close button').addEventListener('click',()=>{closeMenu();menu.focus();});
  document.querySelector('.nav-backdrop').addEventListener('click',closeMenu);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();menu.focus();}});
  let manifest, page=0, request=0, searchData, searchPromise, queryVersion=0;
  const cache=new Map();
  const normalize=s=>s.toLowerCase().replace(/ё/g,'е').replace(/\s+/g,' ').trim();
  const loaded = fetch('manifest.json').then(r=>{if(!r.ok)throw Error('manifest');return r.json();}).then(data=>{
    manifest=data;
    for(const c of data.categories){const o=document.createElement('option');o.value=c.id;o.textContent=c.title;select.append(o);}
    return data;
  });
  function highlight(hash){
    document.querySelectorAll('.sidebar .nav-selected').forEach(a=>a.classList.remove('nav-selected'));
    const link=Array.from(document.querySelectorAll('.sidebar a[href^="#"]')).find(a=>decodeURIComponent(a.hash.slice(1))===hash);
    if(link){link.classList.add('nav-selected');let parent=link.parentElement;while(parent){if(parent.tagName==='DETAILS')parent.open=true;parent=parent.parentElement;}}
  }
  async function show(index,target,scroll=true){
    const version=++request;page=index;const meta=manifest.pages[index];
    if(!meta)return;
    view.setAttribute('aria-busy','true');
    try{
      let text=cache.get(index);
      if(!text){const r=await fetch(meta.file);if(!r.ok)throw Error('page');text=await r.text();cache.set(index,text);if(cache.size>8)cache.delete(cache.keys().next().value);}
      if(version!==request)return;
      view.innerHTML=text;
      window.enhanceOGECards?.();
      select.value=meta.category;
      const group=manifest.categories.find(c=>c.id===meta.category), position=group.pages.indexOf(index);
      document.querySelectorAll('[data-page="prev"]').forEach(b=>b.disabled=position===0);
      document.querySelectorAll('[data-page="next"]').forEach(b=>b.disabled=position===group.pages.length-1);
      document.querySelectorAll('.page-label').forEach(el=>el.textContent=`Страница ${position+1} из ${group.pages.length}`);
      $('page-count').textContent=`На странице ${meta.qids.length} карточек · всего в банке ${manifest.total}`;
      if(scroll){const el=target&&document.getElementById(target);(el||document.querySelector('.task-browser')).scrollIntoView({block:'start'});}
      highlight(target||meta.category);
    }catch(e){if(version!==request)return;view.replaceChildren();const p=document.createElement('p');p.textContent='Не удалось загрузить карточки. Проверьте подключение и повторите.';const b=document.createElement('button');b.textContent='Повторить';b.onclick=()=>show(index,target,scroll);view.append(p,b);}
    finally{if(version===request)view.setAttribute('aria-busy','false');}
  }
  async function route(initial=false){
    try{await loaded;const id=decodeURIComponent(location.hash.slice(1));
      if(/^page-\d+$/.test(id)){const i=Number(id.slice(5));await show(manifest.pages[i]?i:0,null,!initial);}
      else if(Object.hasOwn(manifest.anchors,id)){await show(manifest.anchors[id],id,!initial||!!id);}
      else if(id&&document.getElementById(id)){$('site-guide').open=true;document.getElementById(id).scrollIntoView();if(!view.querySelector('.task'))await show(0,null,false);}
      else await show(0,null,!initial);
    }catch(e){view.innerHTML='<p>Не удалось загрузить список заданий. Обновите страницу, чтобы повторить.</p>';view.setAttribute('aria-busy','false');}
  }
  function navigate(hash){closeMenu();if(location.hash==='#'+hash)route();else location.hash=hash;}
  window.addEventListener('hashchange',()=>route());
  select.addEventListener('change',()=>navigate(select.value));
  document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>{const ids=manifest.categories.find(c=>c.id===manifest.pages[page].category).pages;const i=ids.indexOf(page)+(b.dataset.page==='next'?1:-1);if(ids[i]!==undefined)navigate('page-'+ids[i]);}));
  document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(!a||!a.hash)return;const id=decodeURIComponent(a.hash.slice(1));if(manifest&&(Object.hasOwn(manifest.anchors,id)||document.getElementById(id))){e.preventDefault();navigate(id);}});
  async function search(value,sidebar=false){
    const version=++queryVersion,q=normalize(value),box=$(sidebar?'site-search-results':'bank-search-results');
    if(!q){box.hidden=true;box.classList.remove('open');box.replaceChildren();return;}
    box.hidden=false;box.classList.add('open');box.textContent='Поиск по всему банку…';
    try{
      searchPromise ||= fetch('search.json').then(r=>{if(!r.ok)throw Error('search');return r.json();}).then(rows=>rows.map(row=>({...row,key:normalize(row.q+' '+row.n+' '+row.c+' '+row.t)}))).catch(e=>{searchPromise=null;throw e;});
      searchData=await searchPromise;if(version!==queryVersion)return;
      const words=q.split(' '), found=searchData.filter(row=>words.every(w=>row.key.includes(w)));
      box.replaceChildren();const label=document.createElement('p');label.textContent=found.length?`Найдено: ${found.length}. Выберите карточку.`:'Ничего не найдено. Попробуйте другой запрос.';box.append(label);
      let shown=0;const more=document.createElement('button');more.textContent='Ещё результаты';
      function append(){for(const item of found.slice(shown,shown+20)){const a=document.createElement('a');a.href='#q'+item.q;a.className='search-result';a.textContent=`№${item.n} · ${item.q} — ${item.t}`;a.onclick=()=>{box.hidden=true;box.classList.remove('open');};box.insertBefore(a,more);}shown+=20;more.hidden=shown>=found.length;}
      more.onclick=append;box.append(more);append();
    }catch(e){if(version===queryVersion)box.textContent='Не удалось загрузить поиск. Повторите ввод после восстановления соединения.';}
  }
  let timer;
  for(const input of [$('globalSearch'),$('site-search-input')].filter(Boolean)){
    input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>search(input.value,input.id==='site-search-input'),180);});
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();closeMenu();search(input.value);$('bank-search-results').scrollIntoView({block:'start'});}});
  }
  route(true);
})();
