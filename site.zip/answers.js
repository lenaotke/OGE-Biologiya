function changeFavour(){}
function toggleAll(open){document.querySelectorAll("#task-view details.solve").forEach(function(d){d.open=open;});}
/* ===== ОГЭ-2027 Биология: проверка ответа по ключу карточки и правилам оценивания ФИПИ ===== */
(function(){
  var STORE='oge2027-bio-checks-v1';
  var TOTAL=window.BIO_TOTAL||1979;
  function load(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch(e){return{}}}
  function save(s){try{localStorage.setItem(STORE,JSON.stringify(s))}catch(e){}}

  function norm(v){return String(v==null?'':v).trim().toLowerCase().replace(/ё/g,'е').replace(/[\s.,;:«»"()-]+/g,'');}
  function art(qid){return document.getElementById('q'+qid);}
  function keysOf(qid){var a=art(qid);if(!a)return[];try{return JSON.parse(a.getAttribute('data-keys')||'[]')}catch(e){return[]}}
  function ruleOf(qid){var a=art(qid);return a?(a.getAttribute('data-rule')||'exact'):'exact';}
  function maxOf(qid){var a=art(qid);return a?(+a.getAttribute('data-max')||1):1;}

  function kindOf(form){
    if(form.querySelector('select[name^="ans"]')) return 'select';
    if(form.querySelector('input[type="checkbox"]')) return 'checkbox';
    if(form.querySelector('input[type="radio"][name="answer"]')) return 'radio';
    return 'text';
  }
  function readAnswer(form){
    var sels=[].slice.call(form.querySelectorAll('select[name^="ans"]'));
    if(sels.length){var v=sels.map(function(x){return x.value});return v.some(function(x){return !x||x==='0'})?'':v.join('');}
    var boxes=[].slice.call(form.querySelectorAll('input[type="checkbox"]'));
    if(boxes.length) return boxes.filter(function(x){return x.checked}).map(function(x){return x.value}).sort().join('');
    var r=form.querySelector('input[type="radio"][name="answer"]:checked'); if(r) return r.value;
    var t=form.querySelector('input[type="text"][name="answer"]'); return t?t.value:'';
  }
  /* баллы по правилам спецификации ФИПИ 2027 */
  function score(user,key,rule,max){
    var u=norm(user),k=norm(key);
    if(rule==='exact'||rule==='text') return u===k?max:0;
    if(rule==='set'){
      var us=u.split('').filter(function(c,i,a){return a.indexOf(c)===i}),ks=k.split('');
      var miss=ks.filter(function(c){return us.indexOf(c)<0}).length, extra=us.filter(function(c){return ks.indexOf(c)<0}).length;
      if(!miss&&!extra) return 2;
      if(miss+extra===1) return 1;
      if(miss===1&&extra===1&&us.length===ks.length) return 1;
      return 0;
    }
    var wrong=0,i;
    for(i=0;i<k.length;i++) if(u[i]!==k[i]) wrong++;
    if(rule==='seq2'){var s=wrong===0&&u.length===k.length?2:(wrong<=2?1:0); if(u.length>k.length) s=Math.max(0,s-1); return s;}
    if(u.length>k.length) return 0;
    if(rule==='pos1') return wrong===0?2:(wrong===1?1:0);
    if(rule==='pos2') return wrong===0?3:(wrong===1?2:(wrong===2?1:0));
    return u===k?max:0;
  }
  function best(user,qid){
    var ks=keysOf(qid),rule=ruleOf(qid),max=maxOf(qid),b=0;
    ks.forEach(function(k){b=Math.max(b,score(user,k,rule,max))});
    return {pts:b,max:max};
  }

  var toast,toastTimer;
  function showToast(cls,title,sub){
    if(!toast){toast=document.createElement('div');toast.className='check-toast';toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');document.body.appendChild(toast);}
    toast.className='check-toast '+cls; toast.innerHTML=title+(sub?'<small>'+sub+'</small>':'');
    requestAnimationFrame(function(){toast.classList.add('show')});
    clearTimeout(toastTimer); toastTimer=setTimeout(function(){toast.classList.remove('show')},2800);
  }
  function word(n){n=Math.abs(n)%100;var m=n%10;if(n>10&&n<20)return'баллов';if(m===1)return'балл';if(m>=2&&m<=4)return'балла';return'баллов';}
  function setVisual(qid,panel,res,msgText){
    var ok=res===null?null:res.pts===res.max;
    var status=panel.querySelector('.task-status');
    if(status){
      status.textContent=res===null?'НЕ РЕШЕНО':(ok?'ВЕРНО':(res.pts>0?'ЧАСТИЧНО':'НЕВЕРНО'));
      status.className='task-status '+(res===null?'task-status-0':(ok?'task-status-ok':'task-status-bad'));
    }
    var host=panel.parentNode.parentNode;
    var msg=host.querySelector('.fipi-check-message');
    if(!msg){msg=document.createElement('div');msg.className='fipi-check-message';host.appendChild(msg);}
    msg.className='fipi-check-message'+(res===null?'':(ok?' ok':' bad'));
    msg.textContent=msgText||'';
    var form=document.forms['checkform'+qid];
    var inp=form&&form.querySelector('input[type="text"][name="answer"]');
    if(inp){inp.classList.remove('ans-ok','ans-bad'); if(res!==null) inp.classList.add(ok?'ans-ok':'ans-bad');}
  }
  function resultText(res){
    if(res.pts===res.max) return 'Верно! '+res.pts+' '+word(res.pts)+' из '+res.max+'. Ответ совпал с ответом, подтверждённым на сайте ФИПИ.';
    if(res.pts>0) return 'Частично: '+res.pts+' '+word(res.pts)+' из '+res.max+' по правилам оценивания ФИПИ. Открой решение и найди ошибку.';
    return 'Неверно: 0 баллов из '+res.max+'. Открой «Показать полное решение» и сравни рассуждение.';
  }
  function updateProgress(){
    var s=load(),ok=0,bad=0,self=0;
    Object.keys(s).forEach(function(k){if(k.indexOf('p2_')===0){if(s[k])self++;}else if(s[k]&&s[k].ok===true)ok++;else if(s[k]&&s[k].ok===false)bad++;});
    [['prog-ok',ok],['prog-bad',bad],['prog-saved',self],['prog-none',Math.max(0,TOTAL-ok-bad-self)]].forEach(function(p){var e=document.getElementById(p[0]);if(e)e.textContent=p[1];});
  }
  window.updateProgress=updateProgress;

  function panelQid(panel){var t=panel.parentNode.querySelector('.id-text .canselect');return t?t.textContent.trim():'';}
  function setSelf(panel,done){
    var st=panel.querySelector('.task-status'); if(!st) return;
    st.textContent=done?'РЕШЕНО (сверено с критериями)':'НЕ РЕШЕНО';
    st.className='task-status '+(done?'task-status-self':'task-status-0');
  }
  window.changeStatus=function(guid,panel){
    var qid=panelQid(panel); var s=load(); var done=!(s['p2_'+qid]);
    if(done) s['p2_'+qid]=1; else delete s['p2_'+qid]; save(s);
    setSelf(panel,done); updateProgress();
    showToast(done?'ok':'info',done?'Отмечено: решено':'Статус снят',done?'сверь свой ответ с элементами критериев':'задание снова «не решено»');
  };
  window.checkButtonClick=function(formName,setter,panel){
    var form=document.forms[formName]; if(!form) return false;
    var qid=formName.replace(/^checkform/,'');
    var user=readAnswer(form);
    if(!norm(user)){setVisual(qid,panel,null,'Сначала введи или выбери ответ.');showToast('info','Введи свой ответ','поле ответа пустое');return false;}
    if(!keysOf(qid).length){showToast('info','Нет ключа','проверь по ссылке на сайт ФИПИ');return false;}
    var res=best(user,qid), ok=res.pts===res.max;
    setVisual(qid,panel,res,resultText(res));
    showToast(ok?'ok':'bad',ok?'✓ Верно!':(res.pts?'≈ Частично':'✗ Неверно'),res.pts+' из '+res.max);
    var s=load(); s[qid]={v:user,ok:ok,p:res.pts}; save(s); updateProgress();
    return false;
  };
  window.resetAllProgress=function(){
    if(!confirm('Сбросить все введённые ответы и статусы?')) return;
    try{localStorage.removeItem(STORE)}catch(e){}
    document.querySelectorAll('form[name^="checkform"]').forEach(function(f){
      f.querySelectorAll('input[type=radio],input[type=checkbox]').forEach(function(x){x.checked=false});
      f.querySelectorAll('input[type=text]').forEach(function(x){x.value='';x.classList.remove('ans-ok','ans-bad')});
      f.querySelectorAll('select').forEach(function(x){x.selectedIndex=0});
    });
    document.querySelectorAll('.answer-panel .task-status').forEach(function(st){st.textContent='НЕ РЕШЕНО';st.className='task-status task-status-0';});
    document.querySelectorAll('.fipi-check-message').forEach(function(m){m.remove()});
    updateProgress();
  };
  function enhanceForms(){
    var saved=load();
    document.querySelectorAll('form[name^="checkform"]').forEach(function(form){
      var qid=form.name.replace(/^checkform/,'');
      var a=art(qid); if(!a||a.getAttribute('data-part')==='2') return;
      var block=form.querySelector('td.varinats-block')||form;
      if(!block.querySelector('.ans-label')){
        var lab=document.createElement('div'); lab.className='ans-label';
        lab.textContent=kindOf(form)==='text'?'Введи свой ответ':'Выбери свой ответ';
        var anchor=block.querySelector('a[name="variants"]');
        if(anchor&&anchor.nextSibling&&anchor.nextSibling.nodeName==='BR') anchor.parentNode.removeChild(anchor.nextSibling);
        block.insertBefore(lab,anchor?anchor.nextSibling:block.firstChild);
      }
      var inp=form.querySelector('input[type="text"][name="answer"]');
      if(inp){
        ['autocomplete','autocorrect','autocapitalize'].forEach(function(k){inp.setAttribute(k,'off')});
        inp.setAttribute('spellcheck','false');inp.setAttribute('enterkeyhint','done');inp.removeAttribute('size');
        inp.setAttribute('placeholder',a.getAttribute('data-ph')||'ответ');
        inp.addEventListener('keydown',function(ev){if(ev.key==='Enter'){ev.preventDefault();var b=document.querySelector('#i'+qid+' .answer-button');if(b)b.click();}});
      }
      form.addEventListener('submit',function(ev){ev.preventDefault();});
      window['selectVariant'+qid]=function(k){
        var boxes=form.querySelectorAll('input[type="checkbox"]');
        if(boxes.length){ if(k>=0&&boxes[k]) boxes[k].checked=!boxes[k].checked;
          boxes.forEach(function(b){var tr=b.closest('tr'); if(tr) tr.classList.toggle('checked-distractor',b.checked);}); return; }
        var rs=form.querySelectorAll('input[type="radio"][name="answer"]');
        rs.forEach(function(r,i){var on=(String(i+1)===String(k)); if(on) r.checked=true; var tr=r.closest('tr'); if(tr) tr.classList.toggle('checked-distractor',r.checked);});
      };
      form.querySelectorAll('input[type="radio"][name="answer"]').forEach(function(r){r.addEventListener('change',function(){window['selectVariant'+qid](r.value)})});
      var st=saved[qid];
      if(st){
        if(inp&&st.v!=null) inp.value=st.v;
        else if(st.v){
          var r=form.querySelector('input[type="radio"][name="answer"][value="'+st.v+'"]'); if(r) r.checked=true;
          form.querySelectorAll('input[type="checkbox"]').forEach(function(x){if(String(st.v).indexOf(x.value)>=0)x.checked=true;});
          var sels=form.querySelectorAll('select[name^="ans"]'); String(st.v).split('').forEach(function(c,i){if(sels[i])sels[i].value=c;});
        }
        var panel=document.querySelector('#i'+qid+' .answer-panel');
        if(panel){var res=best(st.v,qid); setVisual(qid,panel,res,resultText(res));}
      }
    });
    document.querySelectorAll('.answer-panel').forEach(function(p){var q=panelQid(p); if(q&&saved['p2_'+q]) setSelf(p,true);});
    updateProgress();
  }
  window.enhanceOGECards=function(){enhanceForms();};
  function init(){window.enhanceOGECards();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
